How to get sound working on Windows 98 FE:
1. Extract the files from the archive to C:\Temp\Wdmdrv.
2. Go to Control Panel -> System, enter Device Manager.
3. Expand "Other devices".
4. Find PCI Multimedia Audio Device, enter its properties.
5. Click on "Reinstall Driver".
6. Click on "Next" twice.
7. Choose "Specify a location", and enter "C:\TempWdmdrv", then click on "Next".
8. Windows should say that it is ready to install the best driver for that device, click on "Next" again.
9. You might encounter an "Insert Disk" error, it is alright, click on "OK".
10. You will get a "Copy files from" dialog, select "C:\Temp\Wdmdrv" and click on "OK".
11. Click on "Finish" to complete the installation.
12. Click on "Close". You have installed the sound driver.
13. Now you have to add a waveset. Copy eapci8m.ecw into C:\Windows\System32.
14. In the Device Manager, expand "Sound, video and game controllers", find "SB PCI(WDM)", enter its properties.
15. In the properties window, click on "Settings".
16. Click on "Add WaveSet" and select the eapci8m.ecw file you've just copied to System32.
17. The new waveset should be displayed as "8 MB GM/GS Waveset ver 5".
18. Click on "OK" and restart Windows 98.

Yes, this is the only way you can get the sound working on the First Edition.
Although the process is convoluted, follow these steps and you will get the sound working in no time :) 

Thank you for downloading from Enderman's website ^_^